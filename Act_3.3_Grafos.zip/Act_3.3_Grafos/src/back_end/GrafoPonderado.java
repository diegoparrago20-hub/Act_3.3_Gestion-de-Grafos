/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;// 20mil librerias jajaja
/**
 *
 * @author coter
 */

public class GrafoPonderado {

////// Grafo en esencia
    private final Map<String, Vertice> vertices;
    private final Map<String, List<Arista>> adyacencia;
    private boolean dirigido;
    private boolean creado;
/////
    public GrafoPonderado() { //constructor
        this.vertices = new LinkedHashMap<>();   // conserva orden de inserción
        this.adyacencia = new LinkedHashMap<>();
        this.dirigido = true;
        this.creado = false;
    }
/// get osea solo lectura
    public boolean isCreado()   { return creado; }
    public boolean isDirigido() { return dirigido; }
    public int getNumVertices() { return vertices.size(); }
    public int getNumAristas()  { return contarAristas(); }

//Metodos de moodle
// Agregar vértice:
    public Vertice agregarVertice(String id, String nombre, String tipo, String estado, double capacidad) {
        verificarGrafo(); // validacion

        id = id == null ? "" : id.trim();
        nombre = nombre == null ? "" : nombre.trim();
        tipo = tipo == null ? "" : tipo.trim();
        estado = estado == null ? "" : estado.trim();

        if (id.isEmpty()) {
            throw new IllegalArgumentException("El identificador es obligatorio");
        }
        if (!id.matches("[A-Za-z0-9_-]{1,20}")) {
            throw new IllegalArgumentException("El identificador debe ser alfanumérico (letras, dígitos, '-' o '_'), máximo 20 caracteres");
        }
        if (vertices.containsKey(id)) {
            throw new IllegalArgumentException("Ya existe una ubicación con el ID '" + id);
        }
        if (nombre.isEmpty()) {
            throw new IllegalArgumentException("El nombre es obligatorio");
        }
        if (tipo.isEmpty()) {
            throw new IllegalArgumentException("El tipo es obligatorio");
        }
        if (estado.isEmpty()) {
            throw new IllegalArgumentException("El estado/zona es obligatorio");
        }
        if (!Double.isFinite(capacidad) || capacidad < 0) {
            throw new IllegalArgumentException("La capacidad debe ser un número finito mayor o igual a cero");
        }

        Vertice v = new Vertice(id, nombre, tipo, estado, capacidad); //crea el grafo
        vertices.put(id, v);
        adyacencia.put(id, new ArrayList<>());
        return v;
    }
// Agregar arista: 
    public Arista agregarArista(String origen, String destino, double peso) {
        verificarNoVacio();
    //validaciones
        origen = origen == null ? "" : origen.trim();
        destino = destino == null ? "" : destino.trim();

        if (origen.isEmpty() || destino.isEmpty()) {
            throw new IllegalArgumentException("Debe indicar el vértice de origen y el de destino");
        }
        if (!vertices.containsKey(origen)) {
            throw new IllegalArgumentException("El vértice origen '" + origen + "' no existe");
        }
        if (!vertices.containsKey(destino)) {
            throw new IllegalArgumentException("El vértice destino '" + destino + "' no existe");
        }
        if (origen.equals(destino)) {
            throw new IllegalArgumentException("No se permite una arista de un vértice hacia sí mismo");
        }
        if (!Double.isFinite(peso) || peso <= 0) {
            throw new IllegalArgumentException(
                "El peso/distancia debe ser un número finito y positivo");
        }

        Arista existente = buscarArista(origen, destino);
        if (existente != null) {
            throw new IllegalArgumentException("Ya existe una ruta de " + origen + " a " + destino
                + " (peso " + String.format("%.2f", existente.getPeso()) + ")");
        }
        if (!dirigido && buscarArista(destino, origen) != null) {
            throw new IllegalArgumentException("Ya existe una ruta entre " + origen + " y " + destino);
        }

        Arista a = new Arista(origen, destino, peso);
        adyacencia.get(origen).add(a);

        if (!dirigido) {
            adyacencia.get(destino).add(new Arista(destino, origen, peso));
        }
        return a;
    }

// Eliminar vértice: 
    public int eliminarVertice(String id) {
        verificarNoVacio();
        id = id == null ? "" : id.trim();
        if (!vertices.containsKey(id)) {
            throw new IllegalArgumentException("No se encontró el vértice '" + id + "'.");
        }

        int eliminadas = 0;
        if (dirigido) {
            List<Arista> salientes = adyacencia.get(id);
            if (salientes != null) {
                eliminadas += salientes.size();
                salientes.clear();
            }
            for (List<Arista> lista : adyacencia.values()) {
                Iterator<Arista> it = lista.iterator();
                while (it.hasNext()) {
                    if (it.next().getDestino().equals(id)) {
                        it.remove();
                        eliminadas++;
                    }
                }
            }
        } else {
            // En no dirigido, cada arista está en dos listas: cuento solo las salientes
            List<Arista> salientes = adyacencia.get(id);
            if (salientes != null) eliminadas = salientes.size();
            // Limpio la referencia inversa en los vecinos
            final String idBuscado = id;
            for (List<Arista> lista : adyacencia.values()) {
                lista.removeIf(a -> a.getDestino().equals(idBuscado));
            }
        }
        vertices.remove(id);
        adyacencia.remove(id);
        return eliminadas;
    }
    public Collection<Vertice> getVertices() {
        return Collections.unmodifiableCollection(vertices.values());
    }
// Eliminar arista: 
    public double eliminarArista(String origen, String destino) {
        verificarNoVacio();

        origen = origen == null ? "" : origen.trim();
        destino = destino == null ? "" : destino.trim();

        if (!vertices.containsKey(origen)) {
            throw new IllegalArgumentException("El vértice origen '" + origen + "' no existe");
        }
        if (!vertices.containsKey(destino)) {
            throw new IllegalArgumentException("El vértice destino '" + destino + "' no existe");
        }

        Arista a = buscarArista(origen, destino);
        if (a == null) {
            if (!dirigido && buscarArista(destino, origen) != null) {
                throw new IllegalArgumentException("La ruta está registrada como " + destino + " -> " + origen
                    + "; indíquela en ese orden.");
            }
            throw new IllegalArgumentException("No existe una ruta de " + origen + " a " + destino + ".");
        }

        adyacencia.get(origen).remove(a);
        if (!dirigido) {
            Arista inversa = buscarArista(destino, origen);
            if (inversa != null) adyacencia.get(destino).remove(inversa);
        }
        return a.getPeso();
    }
    
// Buscar vértice: 
    public Vertice buscarVertice(String id) {
        verificarGrafo();
        return vertices.get(id == null ? "" : id.trim()); // si no existe es null
    }
    // Apoyo de buscar vértice y lanzar excepción si no existe
    public Vertice buscarVerticeObligatorio(String id) {
        Vertice v = buscarVertice(id);
        if (v == null) {
            throw new IllegalArgumentException("No se encontró el vértice '" + id + "'.");
        }
        return v;
    }

// Recorrido BFS: 
    public List<String> bfs(String origen) {
        verificarNoVacio();
        origen = origen == null ? "" : origen.trim(); // cola (Queue) + conjunto de visitados
        if (!vertices.containsKey(origen)) {
            throw new IllegalArgumentException("El vértice inicial '" + origen + "' no existe");
        }

        List<String> secuencia = new ArrayList<>();
        Set<String> visitados = new HashSet<>();
        Queue<String> cola = new LinkedList<>();

        visitados.add(origen);
        cola.add(origen);

        while (!cola.isEmpty()) {
            String actual = cola.poll();
            secuencia.add(actual);
            for (Arista a : adyacencia.get(actual)) {
                if (visitados.add(a.getDestino())) {
                    cola.add(a.getDestino());
                }
            }
        }
        return secuencia;
    }
// Recorrido DFS:
    public List<String> dfs(String origen) {
        verificarNoVacio();
        origen = origen == null ? "" : origen.trim(); // pila (Deque) + conjunto de visitados
        if (!vertices.containsKey(origen)) {
            throw new IllegalArgumentException("El vértice inicial '" + origen + "' no existe");
        }

        List<String> secuencia = new ArrayList<>();
        Set<String> visitados = new HashSet<>();
        Deque<String> pila = new ArrayDeque<>();
        pila.push(origen);

        while (!pila.isEmpty()) {
            String actual = pila.pop();
            if (!visitados.add(actual)) continue;
            secuencia.add(actual);

            List<Arista> vecinos = adyacencia.get(actual);
            // se apilan en orden inverso para visitar en el orden de la lista
            for (int i = vecinos.size() - 1; i >= 0; i--) {
                String destino = vecinos.get(i).getDestino();
                if (!visitados.contains(destino)) pila.push(destino);
            }
        }
        return secuencia;
    }

// Obtener Matriz de Adyacencia: 
     public double[][] matrizAdyacencia() {
        verificarNoVacio();
        List<String> ids = new ArrayList<>(vertices.keySet());
        int n = ids.size();
        double[][] m = new double[n][n];

        for (double[] fila : m) Arrays.fill(fila, Double.POSITIVE_INFINITY);

        Map<String, Integer> indice = new HashMap<>();
        for (int i = 0; i < n; i++) {
            indice.put(ids.get(i), i);
            m[i][i] = 0;
        }
        for (Arista a : getAristas()) {
            int f = indice.get(a.getOrigen());
            int c = indice.get(a.getDestino());
            m[f][c] = a.getPeso();
            if (!dirigido) m[c][f] = a.getPeso();
        }
        return m;
    }
    // Matriz de adyacencia obtenida convertida a texto 
    public String matrizComoTexto() {
        verificarNoVacio();
        List<String> ids = new ArrayList<>(vertices.keySet());
        double[][] m = matrizAdyacencia();

        int ancho = 10;
        StringBuilder sb = new StringBuilder();
        sb.append("Matriz de adyacencia (").append(ids.size())
          .append(" x ").append(ids.size()).append(") - ")
          .append(dirigido ? "dirigida" : "no dirigida").append("\n");
        sb.append("Sin conexión = ∞   Diagonal = 0\n\n");

        sb.append(String.format("%" + ancho + "s", ""));
        for (String id : ids) sb.append(String.format("%" + ancho + "s", id));
        sb.append("\n");

        for (int i = 0; i < ids.size(); i++) {
            sb.append(String.format("%" + ancho + "s", ids.get(i)));
            for (int j = 0; j < ids.size(); j++) {
                sb.append(String.format("%" + ancho + "s",
                        Double.isInfinite(m[i][j])
                            ? "∞"
                            : String.format("%.2f", m[i][j])));
            }
            sb.append("\n");
        }
        return sb.toString();
    }

// Evaluar conectividad:
    public Conectividad evaluarConectividad() {
        if (!creado || vertices.isEmpty()) return Conectividad.VACIO;

        if (!dirigido) {
            return esAlcanzableDesdeTodos(null) ? Conectividad.FUERTEMENTE_CONECTADO : Conectividad.DESCONECTADO;
        }

        if (esAlcanzableDesdeTodos(adyacencia)) {
            return Conectividad.FUERTEMENTE_CONECTADO;
        }
        return esAlcanzableDesdeTodos(adyacenciaInversa()) ? Conectividad.DEBILMENTE_CONECTADO : Conectividad.DESCONECTADO;
    }
    //Explicación legible del resultado de conectividad
    public String explicarConectividad() {
        Conectividad c = evaluarConectividad();
        StringBuilder sb = new StringBuilder();
        sb.append("Conectividad: ").append(c.getEtiqueta()).append("\n");

        switch (c) {
            case VACIO:
                sb.append("No hay vértices registrados en el grafo.\n");
                break;
            case FUERTEMENTE_CONECTADO:
                sb.append(dirigido
                    ? "Desde cualquier vértice se puede llegar a todos los demás siguiendo la dirección de las aristas.\n"
                    : "Todos los vértices están unidos por algún camino (grafo conexo)\n");
                break;
            case DEBILMENTE_CONECTADO:
                sb.append("El grafo se conecta solo si se ignoran las direcciones de las aristas\n");
                sb.append(componentesDesconectadas());
                break;
            case DESCONECTADO:
                sb.append("Existen vértices o grupos de vértices sin conexión con el resto\n");
                sb.append(componentesDesconectadas());
                break;
        }
        return sb.toString();
    }
    // Agrupa vértices por componente (ignorando direcciones) para el diagnóstico
    private String componentesDesconectadas() {
        Map<String, List<Arista>> sinDireccion = adyacenciaInversa();
        Set<String> visitados = new HashSet<>();
        List<List<String>> componentes = new ArrayList<>();

        for (String id : vertices.keySet()) {
            if (visitados.contains(id)) continue;
            List<String> comp = new ArrayList<>();
            Deque<String> pila = new ArrayDeque<>();
            pila.push(id);
            while (!pila.isEmpty()) {
                String actual = pila.pop();
                if (!visitados.add(actual)) continue;
                comp.add(actual);
                for (Arista a : sinDireccion.get(actual)) {
                    if (!visitados.contains(a.getDestino())) pila.push(a.getDestino());
                }
            }
            componentes.add(comp);
        }

        if (componentes.size() <= 1) {
            return "  Todas las ubicaciones forman un solo grupo.\n";
        }

        StringBuilder sb = new StringBuilder("  Componentes detectadas: ")
                .append(componentes.size()).append("\n");
        for (int i = 0; i < componentes.size(); i++) {
            sb.append("    Grupo ").append(i + 1).append(": ")
              .append(String.join(", ", componentes.get(i))).append("\n");
        }
        return sb.toString();
    }
    // Copia de la adyacencia con aristas inversas añadidas
    private Map<String, List<Arista>> adyacenciaInversa() {
        Map<String, List<Arista>> copia = new LinkedHashMap<>();
        for (String id : vertices.keySet()) copia.put(id, new ArrayList<>());
        for (List<Arista> lista : adyacencia.values()) {
            for (Arista a : lista) {
                copia.get(a.getOrigen()).add(
                    new Arista(a.getOrigen(), a.getDestino(), a.getPeso()));
                copia.get(a.getDestino()).add(
                    new Arista(a.getDestino(), a.getOrigen(), a.getPeso()));
            }
        }
        return copia;
    }
    private boolean esAlcanzableDesdeTodos(Map<String, List<Arista>> mapa) {
        Map<String, List<Arista>> usar = (mapa == null) ? adyacencia : mapa;
        int n = vertices.size();
        for (String inicio : vertices.keySet()) {
            Set<String> visitados = new HashSet<>();
            Deque<String> pila = new ArrayDeque<>();
            pila.push(inicio);
            while (!pila.isEmpty()) {
                String actual = pila.pop();
                if (!visitados.add(actual)) continue;
                for (Arista a : usar.get(actual)) {
                    if (!visitados.contains(a.getDestino())) pila.push(a.getDestino());
                }
            }
            if (visitados.size() != n) return false;
        }
        return true;
    }

// Destruir grafo:
    public void destruirGrafo() {
        vertices.clear();
        adyacencia.clear();
        creado = false;
        dirigido = false;
    }

//Crear grafo (no lo pide explisiatemnet pero pues si no dende trabajamos)
    public void crearGrafo(boolean dirigido) {
        if (creado) {
            throw new IllegalStateException("Ya existe un grafo. Use 'Destruir grafo' primero");
        }
        vertices.clear();
        adyacencia.clear();
        this.dirigido = dirigido;
        this.creado = true;
    }

//mas apoyo   
    private void verificarGrafo() {
        if (!creado) {
            throw new IllegalStateException(
                "El grafo no existe. Utilice 'Crear grafo' primero.");
        }
    }
    private void verificarNoVacio() {
        verificarGrafo();
        if (vertices.isEmpty()) {
            throw new IllegalStateException(
                "El grafo está vacío: no hay vértices registrados.");
        }
    }
    private Arista buscarArista(String origen, String destino) {// Devuelve la arista origen->destino o null si no existe
        List<Arista> lista = adyacencia.get(origen);
        if (lista == null) return null;
        for (Arista a : lista) {
            if (a.getDestino().equals(destino)) return a;
        }
        return null;
    }
    private int contarAristas() {
        int total = 0;
        for (List<Arista> lista : adyacencia.values()) total += lista.size();
        return dirigido ? total : total / 2;
    }
    public List<Arista> getAristas() {
        List<Arista> resultado = new ArrayList<>();
        Set<String> vistas = new HashSet<>();
        for (List<Arista> lista : adyacencia.values()) {
            for (Arista a : lista) {
                String clave = dirigido
                        ? a.getOrigen() + ">" + a.getDestino()
                        : (a.getOrigen().compareTo(a.getDestino()) < 0
                            ? a.getOrigen() + ">" + a.getDestino()
                            : a.getDestino() + ">" + a.getOrigen());
                if (vistas.add(clave)) resultado.add(a);
            }
        }
        return resultado;
    }
    public enum Conectividad { // para indicar el tipo de conectividad
            FUERTEMENTE_CONECTADO("Fuertemente conectado"),
            DEBILMENTE_CONECTADO("Débilmente conectado"),
            DESCONECTADO("Desconectado"),
            VACIO("Grafo vacío");

            private final String etiqueta;
            Conectividad(String etiqueta) { this.etiqueta = etiqueta; }
            public String getEtiqueta() { return etiqueta; }
            @Override public String toString() { return etiqueta; }
    }
}// final
